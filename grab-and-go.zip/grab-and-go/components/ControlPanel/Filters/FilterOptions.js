export const storeType = ["All","Restaurant", "Cafe", "Fast Food", "Supermarket"]
export const sortBy = ["Most viewed", "Most rating", "Newest", "Closest to me"]
export const range = ["", "500m", "1km", "2km", "5km"]
export const location = ["", "Eindhoven", "Amsterdam", "Rotterdam", "The Hague"]