export const locationList = [
  {
    name: "Albert Heijn",
    address: "Woenselse Markt 5, 5612 CP Eindhoven, Netherlands",
    lat: 51.4517023,
    lng: 5.4722792
  },
  {
    name: "Action",
    address: "Orionstraat 137, 5632 DC Eindhoven, Netherlands",
    lat: 51.470346,
    lng: 5.4941355
  },
  {
    name: "Chinese food",
    address: "Langdonkenstraat 7, 5616 PN Eindhoven",
    lat: 51.440040,
    lng: 5.464760
  },
  {
    name: "KFC",
    address: "Marktstraat 1, 5611 AE Eindhoven",
    lat: 51.439440,
    lng: 5.477920
  },
  {
    name: "De burger",
    address: "Kerkstraat 5, 5611 GH Eindhoven",
    lat: 51.436770,
    lng: 5.478520
  },
  
];
