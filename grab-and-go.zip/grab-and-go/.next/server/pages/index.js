module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/locationList.js":
/*!********************************!*\
  !*** ./assets/locationList.js ***!
  \********************************/
/*! exports provided: locationList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "locationList", function() { return locationList; });
const locationList = [{
  name: "Albert Heijn",
  address: "Woenselse Markt 5, 5612 CP Eindhoven, Netherlands",
  lat: 51.4517023,
  lng: 5.4722792
}, {
  name: "Action",
  address: "Orionstraat 137, 5632 DC Eindhoven, Netherlands",
  lat: 51.470346,
  lng: 5.4941355
}, {
  name: "Chinese food",
  address: "Langdonkenstraat 7, 5616 PN Eindhoven",
  lat: 51.440040,
  lng: 5.464760
}, {
  name: "KFC",
  address: "Marktstraat 1, 5611 AE Eindhoven",
  lat: 51.439440,
  lng: 5.477920
}, {
  name: "De burger",
  address: "Kerkstraat 5, 5611 GH Eindhoven",
  lat: 51.436770,
  lng: 5.478520
}];

/***/ }),

/***/ "./components/ControlPanel/ControlPanel.js":
/*!*************************************************!*\
  !*** ./components/ControlPanel/ControlPanel.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Filters_FiltersBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Filters/FiltersBox */ "./components/ControlPanel/Filters/FiltersBox.js");
/* harmony import */ var _Stores_StoreList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Stores/StoreList */ "./components/ControlPanel/Stores/StoreList.js");

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\ControlPanel\\ControlPanel.js";




const ControlPanel = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1___default.a.control_panel,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Filters_FiltersBox__WEBPACK_IMPORTED_MODULE_2__["default"], {
        handleFilterChange: e => props.handleFilterChange(e)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Stores_StoreList__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ControlPanel);

/***/ }),

/***/ "./components/ControlPanel/Filters/FilterOptions.js":
/*!**********************************************************!*\
  !*** ./components/ControlPanel/Filters/FilterOptions.js ***!
  \**********************************************************/
/*! exports provided: storeType, sortBy, range, location */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storeType", function() { return storeType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sortBy", function() { return sortBy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "range", function() { return range; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "location", function() { return location; });
const storeType = ["All", "Restaurant", "Cafe", "Fast Food", "Supermarket"];
const sortBy = ["Most viewed", "Most rating", "Newest", "Closest to me"];
const range = ["", "500m", "1km", "2km", "5km"];
const location = ["", "Eindhoven", "Amsterdam", "Rotterdam", "The Hague"];

/***/ }),

/***/ "./components/ControlPanel/Filters/FilterSelect.js":
/*!*********************************************************!*\
  !*** ./components/ControlPanel/Filters/FilterSelect.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/InputLabel */ "@material-ui/core/InputLabel");
/* harmony import */ var _material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/FormControl */ "@material-ui/core/FormControl");
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Select */ "@material-ui/core/Select");
/* harmony import */ var _material_ui_core_Select__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Select__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _FilterOptions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./FilterOptions */ "./components/ControlPanel/Filters/FilterOptions.js");

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\ControlPanel\\Filters\\FilterSelect.js";








const FilterSelect = props => {
  {}
  const {
    0: selectedValue,
    1: setSelectedValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  let options = [];

  switch (props.name) {
    case "storeType":
      options = _FilterOptions__WEBPACK_IMPORTED_MODULE_7__["storeType"];
      break;

    case "sortBy":
      options = _FilterOptions__WEBPACK_IMPORTED_MODULE_7__["sortBy"];
      break;

    case "range":
      options = _FilterOptions__WEBPACK_IMPORTED_MODULE_7__["range"];
      break;

    case "location":
      options = _FilterOptions__WEBPACK_IMPORTED_MODULE_7__["location"];
      break;

      dafault: break;

  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4___default.a, {
    className: "w-100 mb-2",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_InputLabel__WEBPACK_IMPORTED_MODULE_3___default.a, {
      htmlFor: `${props.name}-select`,
      children: props.label
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Select__WEBPACK_IMPORTED_MODULE_5___default.a, {
      native: true,
      value: selectedValue,
      onChange: e => props.handleFilterChange(e),
      inputProps: {
        name: props.name,
        id: `${props.name}-select`
      },
      children: options && options.map(option => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          value: option,
          children: option
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 17
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 33,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FilterSelect); // <div className="col-6 my-2">
//   <p className="mb-2">{props.label}</p>
//   <select className="w-100">
//     <option value="1">1</option>
//     <option value="2">2</option>
//     <option value="3">3</option>
//   </select>
// </div>

/***/ }),

/***/ "./components/ControlPanel/Filters/FiltersBox.js":
/*!*******************************************************!*\
  !*** ./components/ControlPanel/Filters/FiltersBox.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _FilterSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FilterSelect */ "./components/ControlPanel/Filters/FilterSelect.js");

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\ControlPanel\\Filters\\FiltersBox.js";




const FiltersBox = props => {
  let filterBoxClasses = ["row", _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default.a.white_container];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "container",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
      className: "dark-green-text",
      children: "Filters"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: filterBoxClasses.join(" "),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-6",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_FilterSelect__WEBPACK_IMPORTED_MODULE_3__["default"], {
          label: "Store Type",
          name: "storeType",
          handleFilterChange: e => props.handleFilterChange(e)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-6",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_FilterSelect__WEBPACK_IMPORTED_MODULE_3__["default"], {
          label: "Sort By",
          name: "sortBy",
          handleFilterChange: e => props.handleFilterChange(e)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-6",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_FilterSelect__WEBPACK_IMPORTED_MODULE_3__["default"], {
          label: "Range",
          name: "range",
          handleFilterChange: e => props.handleFilterChange(e)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-6",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_FilterSelect__WEBPACK_IMPORTED_MODULE_3__["default"], {
          label: "Location",
          name: "location",
          handleFilterChange: e => props.handleFilterChange(e)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FiltersBox);

/***/ }),

/***/ "./components/ControlPanel/Stores/StoreBox.js":
/*!****************************************************!*\
  !*** ./components/ControlPanel/Stores/StoreBox.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\ControlPanel\\Stores\\StoreBox.js";


const StoreBox = props => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_1___default.a.white_container,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "d-flex justify-content-between px-3 align-items-center",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
          className: "dark-green-text",
          children: props.name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "text-muted",
          children: props.address
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "green-text h5",
          children: [props.distance, " km"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (StoreBox);

/***/ }),

/***/ "./components/ControlPanel/Stores/StoreList.js":
/*!*****************************************************!*\
  !*** ./components/ControlPanel/Stores/StoreList.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _StoreBox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StoreBox */ "./components/ControlPanel/Stores/StoreBox.js");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\ControlPanel\\Stores\\StoreList.js";



const StoreList = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "container",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
      className: "dark-green-text mt-3",
      children: "All stores"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row mx-auto",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "Albert Heijn",
        address: "Herentalsebaan 377\r 2160 Wommelgem",
        distance: "1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "KFC",
        address: "Neckerspoel, Stationsplein 22-17, 5611 AD Eindhoven",
        distance: "1.2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "De Burger",
        address: "Neckerspoel, Stationsplein 22-17, 5611 AD Eindhoven",
        distance: "1.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "Action",
        address: "Neckerspoel, Stationsplein 22-17, 5611 AD Eindhoven",
        distance: "1.2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "Chinese food",
        address: "Neckerspoel, Stationsplein 22-17, 5611 AD Eindhoven",
        distance: "1.9"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_StoreBox__WEBPACK_IMPORTED_MODULE_1__["default"], {
        name: "Albert Heijn",
        address: "Neckerspoel, Stationsplein 22-17, 5611 AD Eindhoven",
        distance: "1.2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (StoreList);

/***/ }),

/***/ "./components/Map/Map.js":
/*!*******************************!*\
  !*** ./components/Map/Map.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_geocode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-geocode */ "react-geocode");
/* harmony import */ var react_geocode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_geocode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_locationList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/locationList */ "./assets/locationList.js");
/* harmony import */ var react_google_maps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-google-maps */ "react-google-maps");
/* harmony import */ var react_google_maps__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_google_maps__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mapStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mapStyles */ "./components/Map/mapStyles.js");

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\Map\\Map.js";






const Map = props => {
  // State
  const {
    0: userPosition,
    1: setUserPosition
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: stores,
    1: setStores
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]);
  const {
    0: selectedStore,
    1: setSelectedStore
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    // Get location of user
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(function (position) {
        setUserPosition({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      });
    } else {
      console.log("Geolocation Not Available");
    } // // Push data to a new object array
    // let allLocations = [];
    // // Connect to Google key
    // Geocode.setApiKey(process.env.NEXT_PUBLIC_GOOGLE_KEY);
    // let promises = [];
    // locationList.map((place) => {
    //   promises.push(Geocode.fromAddress(place.address));
    // });
    // Promise.all(promises).then(
    //     (newLocations) => {
    //       newLocations.map((location) => {
    //         //   console.log('location', location)
    //         const { lat, lng } = location.results[0].geometry.location;
    //         // Update coordinates
    //         location = { ...location, lat: lat, lng: lng };
    //         allLocations.push(location);
    //       });
    //     },
    //     (error) => {
    //       console.error(error);
    //     }
    //   );


    setStores(_assets_locationList__WEBPACK_IMPORTED_MODULE_3__["locationList"]); // // Get latitude and longitude from address
    // await Geocode.fromAddress(place.address).then(
    //     (response) => {
    //       const { lat, lng } = response.results[0].geometry.location;
    //       // Update coordinates
    //       place = {...place, lat: lat, lng: lng}
    //       allLocations.push(place);
    //     },
    //     (error) => {
    //       console.error(error);
    //     }
    //   );
    //   setLocations(allLocations);
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["GoogleMap"], {
    defaultZoom: 13,
    defaultCenter: {
      lat: 51.44083,
      lng: 5.47778
    },
    defaultOptions: {
      styles: _mapStyles__WEBPACK_IMPORTED_MODULE_5__["default"]
    },
    children: [userPosition && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["Marker"], {
      position: {
        lat: userPosition.lat,
        lng: userPosition.lng
      },
      icon: {
        url: "/images/userPointer.svg",
        scaledSize: new window.google.maps.Size(45, 50)
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 9
    }, undefined), stores && stores.map((store, idx) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["Marker"], {
      position: {
        lat: store.lat,
        lng: store.lng
      },
      onClick: () => setSelectedStore(store),
      icon: {
        url: "/images/pointer.svg",
        scaledSize: new window.google.maps.Size(45, 50)
      }
    }, idx, false, {
      fileName: _jsxFileName,
      lineNumber: 97,
      columnNumber: 11
    }, undefined)), selectedStore && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["InfoWindow"], {
      position: {
        lat: selectedStore.lat,
        lng: selectedStore.lng
      },
      onCloseClick: () => setSelectedStore(null),
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
          children: [" ", selectedStore.name]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: selectedStore.address
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 114,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 108,
      columnNumber: 9
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 80,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Object(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["withScriptjs"])(Object(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["withGoogleMap"])(Map)));

/***/ }),

/***/ "./components/Map/mapStyles.js":
/*!*************************************!*\
  !*** ./components/Map/mapStyles.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ([{
  "featureType": "landscape.man_made",
  "elementType": "geometry",
  "stylers": [{
    "color": "#f7f1df"
  }]
}, {
  "featureType": "landscape.natural",
  "elementType": "geometry",
  "stylers": [{
    "color": "#d0e3b4"
  }]
}, {
  "featureType": "landscape.natural.terrain",
  "elementType": "geometry",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "featureType": "poi",
  "elementType": "labels",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "featureType": "poi.business",
  "elementType": "all",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "featureType": "poi.medical",
  "elementType": "geometry",
  "stylers": [{
    "color": "#fbd3da"
  }]
}, {
  "featureType": "poi.park",
  "elementType": "geometry",
  "stylers": [{
    "color": "#bde6ab"
  }]
}, {
  "featureType": "road",
  "elementType": "all",
  "stylers": [{
    "visibility": "on"
  }]
}, {
  "featureType": "road",
  "elementType": "geometry.stroke",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "featureType": "road",
  "elementType": "labels",
  "stylers": [{
    "visibility": "on"
  }]
}, {
  "featureType": "road.highway",
  "elementType": "geometry.fill",
  "stylers": [{
    "color": "#ffe15f"
  }]
}, {
  "featureType": "road.highway",
  "elementType": "geometry.stroke",
  "stylers": [{
    "color": "#efd151"
  }]
}, {
  "featureType": "road.arterial",
  "elementType": "geometry.fill",
  "stylers": [{
    "color": "#ffffff"
  }]
}, {
  "featureType": "road.local",
  "elementType": "geometry.fill",
  "stylers": [{
    "color": "black"
  }]
}, {
  "featureType": "transit",
  "elementType": "geometry",
  "stylers": [{
    "visibility": "off"
  }]
}, {
  "featureType": "transit.station.airport",
  "elementType": "geometry.fill",
  "stylers": [{
    "color": "#cfb2db"
  }]
}, {
  "featureType": "water",
  "elementType": "geometry",
  "stylers": [{
    "color": "#a2daf2"
  }]
}]);

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ControlPanel_ControlPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/ControlPanel/ControlPanel */ "./components/ControlPanel/ControlPanel.js");
/* harmony import */ var _components_Map_Map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Map/Map */ "./components/Map/Map.js");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Home.module.scss */ "./styles/Home.module.scss");
/* harmony import */ var _styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\pages\\index.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class Home extends react__WEBPACK_IMPORTED_MODULE_2__["PureComponent"] {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      storeType: null,
      sortBy: null,
      range: null,
      location: null
    });

    _defineProperty(this, "handleFilterChange", e => {
      // Update state filter value
      this.setState(_objectSpread(_objectSpread({}, this.state), {}, {
        [e.target.name]: e.target.value
      }));
    });
  }

  render() {
    let mainContainerClasses = [_styles_Home_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.main_container, "row"];
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "mx-auto",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Grab and Go"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
          rel: "icon",
          href: "/favicon.ico"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("main", {
        className: mainContainerClasses.join(" "),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-lg-7 px-0",
          style: {
            height: "100vh"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Map_Map__WEBPACK_IMPORTED_MODULE_4__["default"], {
            googleMapURL: `https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=${"AIzaSyAOJDDyL012DooU8FHDbH8yLARMV7L4U-o"}`,
            loadingElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: `100%`
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 31
            }, this),
            containerElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: `100%`
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 33
            }, this),
            mapElement: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: `100%`
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 37,
              columnNumber: 27
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col-12 col-lg-5 px-0",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_ControlPanel_ControlPanel__WEBPACK_IMPORTED_MODULE_3__["default"], {
            handleFilterChange: e => this.handleFilterChange(e)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, this);
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Home);

/***/ }),

/***/ "./styles/Home.module.scss":
/*!*********************************!*\
  !*** ./styles/Home.module.scss ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"main_container": "Home_main_container__O-Zha",
	"control_panel": "Home_control_panel__1E6Js",
	"white_container": "Home_white_container__2nJf2"
};


/***/ }),

/***/ "@material-ui/core/FormControl":
/*!************************************************!*\
  !*** external "@material-ui/core/FormControl" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/FormControl");

/***/ }),

/***/ "@material-ui/core/InputLabel":
/*!***********************************************!*\
  !*** external "@material-ui/core/InputLabel" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/InputLabel");

/***/ }),

/***/ "@material-ui/core/Select":
/*!*******************************************!*\
  !*** external "@material-ui/core/Select" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Select");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-geocode":
/*!********************************!*\
  !*** external "react-geocode" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-geocode");

/***/ }),

/***/ "react-google-maps":
/*!************************************!*\
  !*** external "react-google-maps" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-google-maps");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vYXNzZXRzL2xvY2F0aW9uTGlzdC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0NvbnRyb2xQYW5lbC9Db250cm9sUGFuZWwuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9Db250cm9sUGFuZWwvRmlsdGVycy9GaWx0ZXJPcHRpb25zLmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvQ29udHJvbFBhbmVsL0ZpbHRlcnMvRmlsdGVyU2VsZWN0LmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvQ29udHJvbFBhbmVsL0ZpbHRlcnMvRmlsdGVyc0JveC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0NvbnRyb2xQYW5lbC9TdG9yZXMvU3RvcmVCb3guanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9Db250cm9sUGFuZWwvU3RvcmVzL1N0b3JlTGlzdC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL01hcC9NYXAuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9NYXAvbWFwU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3BhZ2VzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3N0eWxlcy9Ib21lLm1vZHVsZS5zY3NzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0Zvcm1Db250cm9sXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvSW5wdXRMYWJlbFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL1NlbGVjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3N0eWxlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtZ2VvY29kZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWdvb2dsZS1tYXBzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiXSwibmFtZXMiOlsibG9jYXRpb25MaXN0IiwibmFtZSIsImFkZHJlc3MiLCJsYXQiLCJsbmciLCJDb250cm9sUGFuZWwiLCJwcm9wcyIsImNsYXNzZXMiLCJjb250cm9sX3BhbmVsIiwiZSIsImhhbmRsZUZpbHRlckNoYW5nZSIsInN0b3JlVHlwZSIsInNvcnRCeSIsInJhbmdlIiwibG9jYXRpb24iLCJGaWx0ZXJTZWxlY3QiLCJzZWxlY3RlZFZhbHVlIiwic2V0U2VsZWN0ZWRWYWx1ZSIsInVzZVN0YXRlIiwib3B0aW9ucyIsImZpbHRlck9wdGlvbnMiLCJkYWZhdWx0IiwibGFiZWwiLCJpZCIsIm1hcCIsIm9wdGlvbiIsIkZpbHRlcnNCb3giLCJmaWx0ZXJCb3hDbGFzc2VzIiwid2hpdGVfY29udGFpbmVyIiwiam9pbiIsIlN0b3JlQm94IiwiZGlzdGFuY2UiLCJTdG9yZUxpc3QiLCJNYXAiLCJ1c2VyUG9zaXRpb24iLCJzZXRVc2VyUG9zaXRpb24iLCJzdG9yZXMiLCJzZXRTdG9yZXMiLCJzZWxlY3RlZFN0b3JlIiwic2V0U2VsZWN0ZWRTdG9yZSIsInVzZUVmZmVjdCIsIm5hdmlnYXRvciIsImdlb2xvY2F0aW9uIiwiZ2V0Q3VycmVudFBvc2l0aW9uIiwicG9zaXRpb24iLCJjb29yZHMiLCJsYXRpdHVkZSIsImxvbmdpdHVkZSIsImNvbnNvbGUiLCJsb2ciLCJzdHlsZXMiLCJtYXBTdHlsZXMiLCJ1cmwiLCJzY2FsZWRTaXplIiwid2luZG93IiwiZ29vZ2xlIiwibWFwcyIsIlNpemUiLCJzdG9yZSIsImlkeCIsIndpdGhTY3JpcHRqcyIsIndpdGhHb29nbGVNYXAiLCJIb21lIiwiUHVyZUNvbXBvbmVudCIsInNldFN0YXRlIiwic3RhdGUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInJlbmRlciIsIm1haW5Db250YWluZXJDbGFzc2VzIiwibWFpbl9jb250YWluZXIiLCJoZWlnaHQiLCJwcm9jZXNzIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDeEZBO0FBQUE7QUFBTyxNQUFNQSxZQUFZLEdBQUcsQ0FDMUI7QUFDRUMsTUFBSSxFQUFFLGNBRFI7QUFFRUMsU0FBTyxFQUFFLG1EQUZYO0FBR0VDLEtBQUcsRUFBRSxVQUhQO0FBSUVDLEtBQUcsRUFBRTtBQUpQLENBRDBCLEVBTzFCO0FBQ0VILE1BQUksRUFBRSxRQURSO0FBRUVDLFNBQU8sRUFBRSxpREFGWDtBQUdFQyxLQUFHLEVBQUUsU0FIUDtBQUlFQyxLQUFHLEVBQUU7QUFKUCxDQVAwQixFQWExQjtBQUNFSCxNQUFJLEVBQUUsY0FEUjtBQUVFQyxTQUFPLEVBQUUsdUNBRlg7QUFHRUMsS0FBRyxFQUFFLFNBSFA7QUFJRUMsS0FBRyxFQUFFO0FBSlAsQ0FiMEIsRUFtQjFCO0FBQ0VILE1BQUksRUFBRSxLQURSO0FBRUVDLFNBQU8sRUFBRSxrQ0FGWDtBQUdFQyxLQUFHLEVBQUUsU0FIUDtBQUlFQyxLQUFHLEVBQUU7QUFKUCxDQW5CMEIsRUF5QjFCO0FBQ0VILE1BQUksRUFBRSxXQURSO0FBRUVDLFNBQU8sRUFBRSxpQ0FGWDtBQUdFQyxLQUFHLEVBQUUsU0FIUDtBQUlFQyxLQUFHLEVBQUU7QUFKUCxDQXpCMEIsQ0FBckIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQVA7QUFDQTtBQUNBOztBQUVBLE1BQU1DLFlBQVksR0FBSUMsS0FBRCxJQUFXO0FBQzlCLHNCQUNFO0FBQUssYUFBUyxFQUFFQywrREFBTyxDQUFDQyxhQUF4QjtBQUFBLDRCQUNFO0FBQUEsNkJBQ0UscUVBQUMsMkRBQUQ7QUFBVywwQkFBa0IsRUFBR0MsQ0FBRCxJQUFPSCxLQUFLLENBQUNJLGtCQUFOLENBQXlCRCxDQUF6QjtBQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUlFO0FBQUEsNkJBQ0UscUVBQUMseURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFVRCxDQVhEOztBQWFlSiwyRUFBZixFOzs7Ozs7Ozs7Ozs7QUNqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1NLFNBQVMsR0FBRyxDQUFDLEtBQUQsRUFBTyxZQUFQLEVBQXFCLE1BQXJCLEVBQTZCLFdBQTdCLEVBQTBDLGFBQTFDLENBQWxCO0FBQ0EsTUFBTUMsTUFBTSxHQUFHLENBQUMsYUFBRCxFQUFnQixhQUFoQixFQUErQixRQUEvQixFQUF5QyxlQUF6QyxDQUFmO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLENBQUMsRUFBRCxFQUFLLE1BQUwsRUFBYSxLQUFiLEVBQW9CLEtBQXBCLEVBQTJCLEtBQTNCLENBQWQ7QUFDQSxNQUFNQyxRQUFRLEdBQUcsQ0FBQyxFQUFELEVBQUssV0FBTCxFQUFrQixXQUFsQixFQUErQixXQUEvQixFQUE0QyxXQUE1QyxDQUFqQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQyxZQUFZLEdBQUlULEtBQUQsSUFBVztBQUM5QixHQUNDO0FBQ0QsUUFBTTtBQUFBLE9BQUNVLGFBQUQ7QUFBQSxPQUFnQkM7QUFBaEIsTUFBb0NDLHNEQUFRLENBQUMsSUFBRCxDQUFsRDtBQUVBLE1BQUlDLE9BQU8sR0FBRyxFQUFkOztBQUVBLFVBQVFiLEtBQUssQ0FBQ0wsSUFBZDtBQUNFLFNBQUssV0FBTDtBQUNFa0IsYUFBTyxHQUFHQyx3REFBVjtBQUNBOztBQUNGLFNBQUssUUFBTDtBQUNFRCxhQUFPLEdBQUdDLHFEQUFWO0FBQ0E7O0FBQ0YsU0FBSyxPQUFMO0FBQ0VELGFBQU8sR0FBR0Msb0RBQVY7QUFDQTs7QUFDRixTQUFLLFVBQUw7QUFDRUQsYUFBTyxHQUFHQyx1REFBVjtBQUNBOztBQUNBQyxhQUFPLEVBQUU7O0FBYmI7O0FBZ0JBLHNCQUNFLHFFQUFDLG9FQUFEO0FBQWEsYUFBUyxFQUFDLFlBQXZCO0FBQUEsNEJBQ0UscUVBQUMsbUVBQUQ7QUFBWSxhQUFPLEVBQUcsR0FBRWYsS0FBSyxDQUFDTCxJQUFLLFNBQW5DO0FBQUEsZ0JBQThDSyxLQUFLLENBQUNnQjtBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUUscUVBQUMsK0RBQUQ7QUFDRSxZQUFNLE1BRFI7QUFFRSxXQUFLLEVBQUVOLGFBRlQ7QUFHRSxjQUFRLEVBQUdQLENBQUQsSUFBT0gsS0FBSyxDQUFDSSxrQkFBTixDQUF5QkQsQ0FBekIsQ0FIbkI7QUFJRSxnQkFBVSxFQUFFO0FBQ1ZSLFlBQUksRUFBRUssS0FBSyxDQUFDTCxJQURGO0FBRVZzQixVQUFFLEVBQUcsR0FBRWpCLEtBQUssQ0FBQ0wsSUFBSztBQUZSLE9BSmQ7QUFBQSxnQkFTRWtCLE9BQU8sSUFBSUEsT0FBTyxDQUFDSyxHQUFSLENBQWFDLE1BQUQsSUFBWTtBQUNsQyw0QkFBTztBQUFRLGVBQUssRUFBRUEsTUFBZjtBQUFBLG9CQUF3QkE7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUDtBQUNELE9BRlc7QUFUYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBbUJELENBMUNEOztBQTRDZVYsMkVBQWYsRSxDQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdEQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTVcsVUFBVSxHQUFJcEIsS0FBRCxJQUFXO0FBSTVCLE1BQUlxQixnQkFBZ0IsR0FBRyxDQUFDLEtBQUQsRUFBUXBCLCtEQUFPLENBQUNxQixlQUFoQixDQUF2QjtBQUVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLFdBQWY7QUFBQSw0QkFDRTtBQUFJLGVBQVMsRUFBQyxpQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQUssZUFBUyxFQUFFRCxnQkFBZ0IsQ0FBQ0UsSUFBakIsQ0FBc0IsR0FBdEIsQ0FBaEI7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsT0FBZjtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQ0UsZUFBSyxFQUFDLFlBRFI7QUFFRSxjQUFJLEVBQUMsV0FGUDtBQUdFLDRCQUFrQixFQUFHcEIsQ0FBRCxJQUFPSCxLQUFLLENBQUNJLGtCQUFOLENBQXlCRCxDQUF6QjtBQUg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVFFO0FBQUssaUJBQVMsRUFBQyxPQUFmO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFDRSxlQUFLLEVBQUMsU0FEUjtBQUVFLGNBQUksRUFBQyxRQUZQO0FBR0UsNEJBQWtCLEVBQUdBLENBQUQsSUFBT0gsS0FBSyxDQUFDSSxrQkFBTixDQUF5QkQsQ0FBekI7QUFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkYsZUFlRTtBQUFLLGlCQUFTLEVBQUMsT0FBZjtBQUFBLCtCQUNFLHFFQUFDLHFEQUFEO0FBQ0UsZUFBSyxFQUFDLE9BRFI7QUFFRSxjQUFJLEVBQUMsT0FGUDtBQUdFLDRCQUFrQixFQUFHQSxDQUFELElBQU9ILEtBQUssQ0FBQ0ksa0JBQU4sQ0FBeUJELENBQXpCO0FBSDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWZGLGVBc0JFO0FBQUssaUJBQVMsRUFBQyxPQUFmO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFDRSxlQUFLLEVBQUMsVUFEUjtBQUVFLGNBQUksRUFBQyxVQUZQO0FBR0UsNEJBQWtCLEVBQUdBLENBQUQsSUFBT0gsS0FBSyxDQUFDSSxrQkFBTixDQUF5QkQsQ0FBekI7QUFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQW1DRCxDQXpDRDs7QUEyQ2VpQix5RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NBOztBQUVBLE1BQU1JLFFBQVEsR0FBSXhCLEtBQUQsSUFBVztBQUMxQixzQkFDRTtBQUFLLGFBQVMsRUFBRUMsK0RBQU8sQ0FBQ3FCLGVBQXhCO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsd0RBQWY7QUFBQSw4QkFDRTtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxpQkFBZDtBQUFBLG9CQUFpQ3RCLEtBQUssQ0FBQ0w7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUcsbUJBQVMsRUFBQyxZQUFiO0FBQUEsb0JBQTJCSyxLQUFLLENBQUNKO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBS0U7QUFBQSwrQkFDRTtBQUFNLG1CQUFTLEVBQUMsZUFBaEI7QUFBQSxxQkFBaUNJLEtBQUssQ0FBQ3lCLFFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBYUQsQ0FkRDs7QUFnQmVELHVFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJBO0FBRUE7O0FBRUEsTUFBTUUsU0FBUyxHQUFHLE1BQU07QUFDdEIsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsV0FBZjtBQUFBLDRCQUNFO0FBQUksZUFBUyxFQUFDLHNCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBSyxlQUFTLEVBQUMsYUFBZjtBQUFBLDhCQUNFLHFFQUFDLGlEQUFEO0FBQ0UsWUFBSSxFQUFDLGNBRFA7QUFFRSxlQUFPLEVBQUMscUNBRlY7QUFJRSxnQkFBUSxFQUFDO0FBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FLHFFQUFDLGlEQUFEO0FBQ0UsWUFBSSxFQUFDLEtBRFA7QUFFRSxlQUFPLEVBQUMscURBRlY7QUFHRSxnQkFBUSxFQUFDO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVlFLHFFQUFDLGlEQUFEO0FBQ0UsWUFBSSxFQUFDLFdBRFA7QUFFRSxlQUFPLEVBQUMscURBRlY7QUFHRSxnQkFBUSxFQUFDO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRixlQWlCRSxxRUFBQyxpREFBRDtBQUNFLFlBQUksRUFBQyxRQURQO0FBRUUsZUFBTyxFQUFDLHFEQUZWO0FBR0UsZ0JBQVEsRUFBQztBQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGLGVBc0JFLHFFQUFDLGlEQUFEO0FBQ0UsWUFBSSxFQUFDLGNBRFA7QUFFRSxlQUFPLEVBQUMscURBRlY7QUFHRSxnQkFBUSxFQUFDO0FBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0QkYsZUEyQkUscUVBQUMsaURBQUQ7QUFDRSxZQUFJLEVBQUMsY0FEUDtBQUVFLGVBQU8sRUFBQyxxREFGVjtBQUdFLGdCQUFRLEVBQUM7QUFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF1Q0QsQ0F4Q0Q7O0FBMENlQSx3RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUNBO0FBQ0E7QUFDQTtBQUNBO0FBT0E7O0FBRUEsTUFBTUMsR0FBRyxHQUFJM0IsS0FBRCxJQUFXO0FBQ3JCO0FBQ0EsUUFBTTtBQUFBLE9BQUM0QixZQUFEO0FBQUEsT0FBZUM7QUFBZixNQUFrQ2pCLHNEQUFRLEVBQWhEO0FBQ0EsUUFBTTtBQUFBLE9BQUNrQixNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQm5CLHNEQUFRLENBQUMsRUFBRCxDQUFwQztBQUNBLFFBQU07QUFBQSxPQUFDb0IsYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFvQ3JCLHNEQUFRLENBQUMsSUFBRCxDQUFsRDtBQUVBc0IseURBQVMsQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFJLGlCQUFpQkMsU0FBckIsRUFBZ0M7QUFDOUJBLGVBQVMsQ0FBQ0MsV0FBVixDQUFzQkMsa0JBQXRCLENBQXlDLFVBQVVDLFFBQVYsRUFBb0I7QUFDM0RULHVCQUFlLENBQUM7QUFDZGhDLGFBQUcsRUFBRXlDLFFBQVEsQ0FBQ0MsTUFBVCxDQUFnQkMsUUFEUDtBQUVkMUMsYUFBRyxFQUFFd0MsUUFBUSxDQUFDQyxNQUFULENBQWdCRTtBQUZQLFNBQUQsQ0FBZjtBQUlELE9BTEQ7QUFNRCxLQVBELE1BT087QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVksMkJBQVo7QUFDRCxLQVhhLENBYWQ7QUFDQTtBQUVBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBWixhQUFTLENBQUNyQyxpRUFBRCxDQUFULENBMUNjLENBNENkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0QsR0ExRFEsRUEwRE4sRUExRE0sQ0FBVDtBQTREQSxzQkFDRSxxRUFBQywyREFBRDtBQUNFLGVBQVcsRUFBRSxFQURmO0FBRUUsaUJBQWEsRUFBRTtBQUFFRyxTQUFHLEVBQUUsUUFBUDtBQUFpQkMsU0FBRyxFQUFFO0FBQXRCLEtBRmpCO0FBR0Usa0JBQWMsRUFBRTtBQUFFOEMsWUFBTSxFQUFFQyxrREFBU0E7QUFBbkIsS0FIbEI7QUFBQSxlQUtHakIsWUFBWSxpQkFDWCxxRUFBQyx3REFBRDtBQUNFLGNBQVEsRUFBRTtBQUFFL0IsV0FBRyxFQUFFK0IsWUFBWSxDQUFDL0IsR0FBcEI7QUFBeUJDLFdBQUcsRUFBRThCLFlBQVksQ0FBQzlCO0FBQTNDLE9BRFo7QUFFRSxVQUFJLEVBQUU7QUFDSmdELFdBQUcsRUFBRSx5QkFERDtBQUVKQyxrQkFBVSxFQUFFLElBQUlDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjQyxJQUFkLENBQW1CQyxJQUF2QixDQUE0QixFQUE1QixFQUFnQyxFQUFoQztBQUZSO0FBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFOSixFQWVHckIsTUFBTSxJQUNMQSxNQUFNLENBQUNaLEdBQVAsQ0FBVyxDQUFDa0MsS0FBRCxFQUFRQyxHQUFSLGtCQUNULHFFQUFDLHdEQUFEO0FBRUUsY0FBUSxFQUFFO0FBQUV4RCxXQUFHLEVBQUV1RCxLQUFLLENBQUN2RCxHQUFiO0FBQWtCQyxXQUFHLEVBQUVzRCxLQUFLLENBQUN0RDtBQUE3QixPQUZaO0FBR0UsYUFBTyxFQUFFLE1BQU1tQyxnQkFBZ0IsQ0FBQ21CLEtBQUQsQ0FIakM7QUFJRSxVQUFJLEVBQUU7QUFDSk4sV0FBRyxFQUFFLHFCQUREO0FBRUpDLGtCQUFVLEVBQUUsSUFBSUMsTUFBTSxDQUFDQyxNQUFQLENBQWNDLElBQWQsQ0FBbUJDLElBQXZCLENBQTRCLEVBQTVCLEVBQWdDLEVBQWhDO0FBRlI7QUFKUixPQUNPRSxHQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsQ0FoQkosRUEyQkdyQixhQUFhLGlCQUNaLHFFQUFDLDREQUFEO0FBQ0UsY0FBUSxFQUFFO0FBQUVuQyxXQUFHLEVBQUVtQyxhQUFhLENBQUNuQyxHQUFyQjtBQUEwQkMsV0FBRyxFQUFFa0MsYUFBYSxDQUFDbEM7QUFBN0MsT0FEWjtBQUVFLGtCQUFZLEVBQUUsTUFBTW1DLGdCQUFnQixDQUFDLElBQUQsQ0FGdEM7QUFBQSw2QkFJRTtBQUFBLGdDQUNFO0FBQUEsMEJBQU1ELGFBQWEsQ0FBQ3JDLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUEsb0JBQUlxQyxhQUFhLENBQUNwQztBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBeUNELENBM0dEOztBQTZHZTBELHFJQUFZLENBQUNDLHVFQUFhLENBQUM1QixHQUFELENBQWQsQ0FBM0IsRTs7Ozs7Ozs7Ozs7O0FDekhBO0FBQWUsZ0VBQ1g7QUFDSSxpQkFBZSxvQkFEbkI7QUFFSSxpQkFBZSxVQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGFBQVM7QUFEYixHQURPO0FBSGYsQ0FEVyxFQVVYO0FBQ0ksaUJBQWUsbUJBRG5CO0FBRUksaUJBQWUsVUFGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxhQUFTO0FBRGIsR0FETztBQUhmLENBVlcsRUFtQlg7QUFDSSxpQkFBZSwyQkFEbkI7QUFFSSxpQkFBZSxVQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGtCQUFjO0FBRGxCLEdBRE87QUFIZixDQW5CVyxFQTRCWDtBQUNJLGlCQUFlLEtBRG5CO0FBRUksaUJBQWUsUUFGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxrQkFBYztBQURsQixHQURPO0FBSGYsQ0E1QlcsRUFxQ1g7QUFDSSxpQkFBZSxjQURuQjtBQUVJLGlCQUFlLEtBRm5CO0FBR0ksYUFBVyxDQUNQO0FBQ0ksa0JBQWM7QUFEbEIsR0FETztBQUhmLENBckNXLEVBOENYO0FBQ0ksaUJBQWUsYUFEbkI7QUFFSSxpQkFBZSxVQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGFBQVM7QUFEYixHQURPO0FBSGYsQ0E5Q1csRUF1RFg7QUFDSSxpQkFBZSxVQURuQjtBQUVJLGlCQUFlLFVBRm5CO0FBR0ksYUFBVyxDQUNQO0FBQ0ksYUFBUztBQURiLEdBRE87QUFIZixDQXZEVyxFQWdFWDtBQUNJLGlCQUFlLE1BRG5CO0FBRUksaUJBQWUsS0FGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxrQkFBYztBQURsQixHQURPO0FBSGYsQ0FoRVcsRUF5RVg7QUFDSSxpQkFBZSxNQURuQjtBQUVJLGlCQUFlLGlCQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGtCQUFjO0FBRGxCLEdBRE87QUFIZixDQXpFVyxFQWtGWDtBQUNJLGlCQUFlLE1BRG5CO0FBRUksaUJBQWUsUUFGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxrQkFBYztBQURsQixHQURPO0FBSGYsQ0FsRlcsRUEyRlg7QUFDSSxpQkFBZSxjQURuQjtBQUVJLGlCQUFlLGVBRm5CO0FBR0ksYUFBVyxDQUNQO0FBQ0ksYUFBUztBQURiLEdBRE87QUFIZixDQTNGVyxFQW9HWDtBQUNJLGlCQUFlLGNBRG5CO0FBRUksaUJBQWUsaUJBRm5CO0FBR0ksYUFBVyxDQUNQO0FBQ0ksYUFBUztBQURiLEdBRE87QUFIZixDQXBHVyxFQTZHWDtBQUNJLGlCQUFlLGVBRG5CO0FBRUksaUJBQWUsZUFGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxhQUFTO0FBRGIsR0FETztBQUhmLENBN0dXLEVBc0hYO0FBQ0ksaUJBQWUsWUFEbkI7QUFFSSxpQkFBZSxlQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGFBQVM7QUFEYixHQURPO0FBSGYsQ0F0SFcsRUErSFg7QUFDSSxpQkFBZSxTQURuQjtBQUVJLGlCQUFlLFVBRm5CO0FBR0ksYUFBVyxDQUNQO0FBQ0ksa0JBQWM7QUFEbEIsR0FETztBQUhmLENBL0hXLEVBd0lYO0FBQ0ksaUJBQWUseUJBRG5CO0FBRUksaUJBQWUsZUFGbkI7QUFHSSxhQUFXLENBQ1A7QUFDSSxhQUFTO0FBRGIsR0FETztBQUhmLENBeElXLEVBaUpYO0FBQ0ksaUJBQWUsT0FEbkI7QUFFSSxpQkFBZSxVQUZuQjtBQUdJLGFBQVcsQ0FDUDtBQUNJLGFBQVM7QUFEYixHQURPO0FBSGYsQ0FqSlcsQ0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTTZCLElBQU4sU0FBbUJDLG1EQUFuQixDQUFpQztBQUFBO0FBQUE7O0FBQUEsbUNBQ3ZCO0FBQ05wRCxlQUFTLEVBQUUsSUFETDtBQUVOQyxZQUFNLEVBQUUsSUFGRjtBQUdOQyxXQUFLLEVBQUUsSUFIRDtBQUlOQyxjQUFRLEVBQUU7QUFKSixLQUR1Qjs7QUFBQSxnREFRVEwsQ0FBRCxJQUFPO0FBQzFCO0FBQ0EsV0FBS3VELFFBQUwsaUNBQW1CLEtBQUtDLEtBQXhCO0FBQ0UsU0FBQ3hELENBQUMsQ0FBQ3lELE1BQUYsQ0FBU2pFLElBQVYsR0FBaUJRLENBQUMsQ0FBQ3lELE1BQUYsQ0FBU0M7QUFENUI7QUFFQyxLQVo0QjtBQUFBOztBQWUvQkMsUUFBTSxHQUFHO0FBQ1AsUUFBSUMsb0JBQW9CLEdBQUcsQ0FBQzlELCtEQUFPLENBQUMrRCxjQUFULEVBQXlCLEtBQXpCLENBQTNCO0FBRUEsd0JBQ0U7QUFBSyxlQUFTLEVBQUMsU0FBZjtBQUFBLDhCQUNFLHFFQUFDLGdEQUFEO0FBQUEsZ0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRTtBQUFNLGFBQUcsRUFBQyxNQUFWO0FBQWlCLGNBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBS0U7QUFBTSxpQkFBUyxFQUFFRCxvQkFBb0IsQ0FBQ3hDLElBQXJCLENBQTBCLEdBQTFCLENBQWpCO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLHNCQUFmO0FBQXNDLGVBQUssRUFBRTtBQUFFMEMsa0JBQU0sRUFBRTtBQUFWLFdBQTdDO0FBQUEsaUNBQ0UscUVBQUMsMkRBQUQ7QUFDRSx3QkFBWSxFQUFHLHlGQUF3RkMseUNBQW1DLEVBRDVJO0FBRUUsMEJBQWMsZUFBRTtBQUFLLG1CQUFLLEVBQUU7QUFBRUQsc0JBQU0sRUFBRztBQUFYO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGbEI7QUFHRSw0QkFBZ0IsZUFBRTtBQUFLLG1CQUFLLEVBQUU7QUFBRUEsc0JBQU0sRUFBRztBQUFYO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIcEI7QUFJRSxzQkFBVSxlQUFFO0FBQUssbUJBQUssRUFBRTtBQUFFQSxzQkFBTSxFQUFHO0FBQVg7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFTRTtBQUFLLG1CQUFTLEVBQUMsc0JBQWY7QUFBQSxpQ0FDRSxxRUFBQyw2RUFBRDtBQUFjLDhCQUFrQixFQUFHOUQsQ0FBRCxJQUFPLEtBQUtDLGtCQUFMLENBQXdCRCxDQUF4QjtBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQXFCRDs7QUF2QzhCOztBQTBDbEJxRCxtRUFBZixFOzs7Ozs7Ozs7OztBQ2hEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0xBLDBEOzs7Ozs7Ozs7OztBQ0FBLHlEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLDBDOzs7Ozs7Ozs7OztBQ0FBLDhDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL2luZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9wYWdlcy9pbmRleC5qc1wiKTtcbiIsImV4cG9ydCBjb25zdCBsb2NhdGlvbkxpc3QgPSBbXHJcbiAge1xyXG4gICAgbmFtZTogXCJBbGJlcnQgSGVpam5cIixcclxuICAgIGFkZHJlc3M6IFwiV29lbnNlbHNlIE1hcmt0IDUsIDU2MTIgQ1AgRWluZGhvdmVuLCBOZXRoZXJsYW5kc1wiLFxyXG4gICAgbGF0OiA1MS40NTE3MDIzLFxyXG4gICAgbG5nOiA1LjQ3MjI3OTJcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiQWN0aW9uXCIsXHJcbiAgICBhZGRyZXNzOiBcIk9yaW9uc3RyYWF0IDEzNywgNTYzMiBEQyBFaW5kaG92ZW4sIE5ldGhlcmxhbmRzXCIsXHJcbiAgICBsYXQ6IDUxLjQ3MDM0NixcclxuICAgIGxuZzogNS40OTQxMzU1XHJcbiAgfSxcclxuICB7XHJcbiAgICBuYW1lOiBcIkNoaW5lc2UgZm9vZFwiLFxyXG4gICAgYWRkcmVzczogXCJMYW5nZG9ua2Vuc3RyYWF0IDcsIDU2MTYgUE4gRWluZGhvdmVuXCIsXHJcbiAgICBsYXQ6IDUxLjQ0MDA0MCxcclxuICAgIGxuZzogNS40NjQ3NjBcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiS0ZDXCIsXHJcbiAgICBhZGRyZXNzOiBcIk1hcmt0c3RyYWF0IDEsIDU2MTEgQUUgRWluZGhvdmVuXCIsXHJcbiAgICBsYXQ6IDUxLjQzOTQ0MCxcclxuICAgIGxuZzogNS40Nzc5MjBcclxuICB9LFxyXG4gIHtcclxuICAgIG5hbWU6IFwiRGUgYnVyZ2VyXCIsXHJcbiAgICBhZGRyZXNzOiBcIktlcmtzdHJhYXQgNSwgNTYxMSBHSCBFaW5kaG92ZW5cIixcclxuICAgIGxhdDogNTEuNDM2NzcwLFxyXG4gICAgbG5nOiA1LjQ3ODUyMFxyXG4gIH0sXHJcbiAgXHJcbl07XHJcbiIsImltcG9ydCBjbGFzc2VzIGZyb20gXCIuLi8uLi9zdHlsZXMvSG9tZS5tb2R1bGUuc2Nzc1wiO1xyXG5pbXBvcnQgRmlsdGVyQm94IGZyb20gXCIuL0ZpbHRlcnMvRmlsdGVyc0JveFwiO1xyXG5pbXBvcnQgU3RvcmVMaXN0IGZyb20gXCIuL1N0b3Jlcy9TdG9yZUxpc3RcIjtcclxuXHJcbmNvbnN0IENvbnRyb2xQYW5lbCA9IChwcm9wcykgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5jb250cm9sX3BhbmVsfT5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8RmlsdGVyQm94IGhhbmRsZUZpbHRlckNoYW5nZT17KGUpID0+IHByb3BzLmhhbmRsZUZpbHRlckNoYW5nZShlKX0vPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8U3RvcmVMaXN0IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRyb2xQYW5lbDtcclxuIiwiZXhwb3J0IGNvbnN0IHN0b3JlVHlwZSA9IFtcIkFsbFwiLFwiUmVzdGF1cmFudFwiLCBcIkNhZmVcIiwgXCJGYXN0IEZvb2RcIiwgXCJTdXBlcm1hcmtldFwiXVxyXG5leHBvcnQgY29uc3Qgc29ydEJ5ID0gW1wiTW9zdCB2aWV3ZWRcIiwgXCJNb3N0IHJhdGluZ1wiLCBcIk5ld2VzdFwiLCBcIkNsb3Nlc3QgdG8gbWVcIl1cclxuZXhwb3J0IGNvbnN0IHJhbmdlID0gW1wiXCIsIFwiNTAwbVwiLCBcIjFrbVwiLCBcIjJrbVwiLCBcIjVrbVwiXVxyXG5leHBvcnQgY29uc3QgbG9jYXRpb24gPSBbXCJcIiwgXCJFaW5kaG92ZW5cIiwgXCJBbXN0ZXJkYW1cIiwgXCJSb3R0ZXJkYW1cIiwgXCJUaGUgSGFndWVcIl0iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIjtcclxuaW1wb3J0IElucHV0TGFiZWwgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0lucHV0TGFiZWxcIjtcclxuaW1wb3J0IEZvcm1Db250cm9sIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9Gb3JtQ29udHJvbFwiO1xyXG5pbXBvcnQgU2VsZWN0IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9TZWxlY3RcIjtcclxuaW1wb3J0IGNsYXNzZXMgZnJvbSBcIi4uLy4uLy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5zY3NzXCI7XHJcbmltcG9ydCAqIGFzIGZpbHRlck9wdGlvbnMgZnJvbSBcIi4vRmlsdGVyT3B0aW9uc1wiO1xyXG5cclxuY29uc3QgRmlsdGVyU2VsZWN0ID0gKHByb3BzKSA9PiB7XHJcbiAge1xyXG4gIH1cclxuICBjb25zdCBbc2VsZWN0ZWRWYWx1ZSwgc2V0U2VsZWN0ZWRWYWx1ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgbGV0IG9wdGlvbnMgPSBbXTtcclxuXHJcbiAgc3dpdGNoIChwcm9wcy5uYW1lKSB7XHJcbiAgICBjYXNlIFwic3RvcmVUeXBlXCI6XHJcbiAgICAgIG9wdGlvbnMgPSBmaWx0ZXJPcHRpb25zLnN0b3JlVHlwZTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwic29ydEJ5XCI6XHJcbiAgICAgIG9wdGlvbnMgPSBmaWx0ZXJPcHRpb25zLnNvcnRCeTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBjYXNlIFwicmFuZ2VcIjpcclxuICAgICAgb3B0aW9ucyA9IGZpbHRlck9wdGlvbnMucmFuZ2U7XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgY2FzZSBcImxvY2F0aW9uXCI6XHJcbiAgICAgIG9wdGlvbnMgPSBmaWx0ZXJPcHRpb25zLmxvY2F0aW9uO1xyXG4gICAgICBicmVhaztcclxuICAgICAgZGFmYXVsdDogYnJlYWs7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEZvcm1Db250cm9sIGNsYXNzTmFtZT1cInctMTAwIG1iLTJcIj5cclxuICAgICAgPElucHV0TGFiZWwgaHRtbEZvcj17YCR7cHJvcHMubmFtZX0tc2VsZWN0YH0+e3Byb3BzLmxhYmVsfTwvSW5wdXRMYWJlbD5cclxuICAgICAgPFNlbGVjdFxyXG4gICAgICAgIG5hdGl2ZVxyXG4gICAgICAgIHZhbHVlPXtzZWxlY3RlZFZhbHVlfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gcHJvcHMuaGFuZGxlRmlsdGVyQ2hhbmdlKGUpfVxyXG4gICAgICAgIGlucHV0UHJvcHM9e3tcclxuICAgICAgICAgIG5hbWU6IHByb3BzLm5hbWUsXHJcbiAgICAgICAgICBpZDogYCR7cHJvcHMubmFtZX0tc2VsZWN0YCxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICB7b3B0aW9ucyAmJiBvcHRpb25zLm1hcCgob3B0aW9uKSA9PiB7XHJcbiAgICAgICAgIHJldHVybiA8b3B0aW9uIHZhbHVlPXtvcHRpb259PntvcHRpb259PC9vcHRpb24+XHJcbiAgICAgICB9KX1cclxuICAgICAgICBcclxuICAgICAgPC9TZWxlY3Q+XHJcbiAgICA8L0Zvcm1Db250cm9sPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGaWx0ZXJTZWxlY3Q7XHJcblxyXG4vLyA8ZGl2IGNsYXNzTmFtZT1cImNvbC02IG15LTJcIj5cclxuLy8gICA8cCBjbGFzc05hbWU9XCJtYi0yXCI+e3Byb3BzLmxhYmVsfTwvcD5cclxuLy8gICA8c2VsZWN0IGNsYXNzTmFtZT1cInctMTAwXCI+XHJcbi8vICAgICA8b3B0aW9uIHZhbHVlPVwiMVwiPjE8L29wdGlvbj5cclxuLy8gICAgIDxvcHRpb24gdmFsdWU9XCIyXCI+Mjwvb3B0aW9uPlxyXG4vLyAgICAgPG9wdGlvbiB2YWx1ZT1cIjNcIj4zPC9vcHRpb24+XHJcbi8vICAgPC9zZWxlY3Q+XHJcbi8vIDwvZGl2PlxyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGNsYXNzZXMgZnJvbSBcIi4uLy4uLy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5zY3NzXCI7XHJcbmltcG9ydCBGaWx0ZXJTZWxlY3QgZnJvbSBcIi4vRmlsdGVyU2VsZWN0XCI7XHJcblxyXG5jb25zdCBGaWx0ZXJzQm94ID0gKHByb3BzKSA9PiB7XHJcbiBcclxuXHJcbiAgXHJcbiAgbGV0IGZpbHRlckJveENsYXNzZXMgPSBbXCJyb3dcIiwgY2xhc3Nlcy53aGl0ZV9jb250YWluZXJdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cImRhcmstZ3JlZW4tdGV4dFwiPkZpbHRlcnM8L2gyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17ZmlsdGVyQm94Q2xhc3Nlcy5qb2luKFwiIFwiKX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNlwiPlxyXG4gICAgICAgICAgPEZpbHRlclNlbGVjdFxyXG4gICAgICAgICAgICBsYWJlbD1cIlN0b3JlIFR5cGVcIlxyXG4gICAgICAgICAgICBuYW1lPVwic3RvcmVUeXBlXCJcclxuICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlPXsoZSkgPT4gcHJvcHMuaGFuZGxlRmlsdGVyQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC02XCI+XHJcbiAgICAgICAgICA8RmlsdGVyU2VsZWN0XHJcbiAgICAgICAgICAgIGxhYmVsPVwiU29ydCBCeVwiXHJcbiAgICAgICAgICAgIG5hbWU9XCJzb3J0QnlcIlxyXG4gICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2U9eyhlKSA9PiBwcm9wcy5oYW5kbGVGaWx0ZXJDaGFuZ2UoZSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTZcIj5cclxuICAgICAgICAgIDxGaWx0ZXJTZWxlY3RcclxuICAgICAgICAgICAgbGFiZWw9XCJSYW5nZVwiXHJcbiAgICAgICAgICAgIG5hbWU9XCJyYW5nZVwiXHJcbiAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZT17KGUpID0+IHByb3BzLmhhbmRsZUZpbHRlckNoYW5nZShlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNlwiPlxyXG4gICAgICAgICAgPEZpbHRlclNlbGVjdFxyXG4gICAgICAgICAgICBsYWJlbD1cIkxvY2F0aW9uXCJcclxuICAgICAgICAgICAgbmFtZT1cImxvY2F0aW9uXCJcclxuICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlPXsoZSkgPT4gcHJvcHMuaGFuZGxlRmlsdGVyQ2hhbmdlKGUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyc0JveDtcclxuIiwiaW1wb3J0IGNsYXNzZXMgZnJvbSBcIi4uLy4uLy4uL3N0eWxlcy9Ib21lLm1vZHVsZS5zY3NzXCI7XHJcblxyXG5jb25zdCBTdG9yZUJveCA9IChwcm9wcykgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy53aGl0ZV9jb250YWluZXJ9PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtYmV0d2VlbiBweC0zIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwiZGFyay1ncmVlbi10ZXh0XCI+e3Byb3BzLm5hbWV9PC9oNT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWRcIj57cHJvcHMuYWRkcmVzc308L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyZWVuLXRleHQgaDVcIj57cHJvcHMuZGlzdGFuY2V9IGttPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdG9yZUJveDtcclxuIiwiaW1wb3J0IFN0b3JlQm94IGZyb20gXCIuL1N0b3JlQm94XCI7XHJcblxyXG5pbXBvcnQgY2xhc3NlcyBmcm9tIFwiLi4vLi4vLi4vc3R5bGVzL0hvbWUubW9kdWxlLnNjc3NcIjtcclxuXHJcbmNvbnN0IFN0b3JlTGlzdCA9ICgpID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cclxuICAgICAgPGgyIGNsYXNzTmFtZT1cImRhcmstZ3JlZW4tdGV4dCBtdC0zXCI+QWxsIHN0b3JlczwvaDI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IG14LWF1dG9cIj5cclxuICAgICAgICA8U3RvcmVCb3hcclxuICAgICAgICAgIG5hbWU9XCJBbGJlcnQgSGVpam5cIlxyXG4gICAgICAgICAgYWRkcmVzcz1cIkhlcmVudGFsc2ViYWFuIDM3N1xyXG4gICAgICAgICAgMjE2MCBXb21tZWxnZW1cIlxyXG4gICAgICAgICAgZGlzdGFuY2U9XCIxXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTdG9yZUJveFxyXG4gICAgICAgICAgbmFtZT1cIktGQ1wiXHJcbiAgICAgICAgICBhZGRyZXNzPVwiTmVja2Vyc3BvZWwsIFN0YXRpb25zcGxlaW4gMjItMTcsIDU2MTEgQUQgRWluZGhvdmVuXCJcclxuICAgICAgICAgIGRpc3RhbmNlPVwiMS4yXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTdG9yZUJveFxyXG4gICAgICAgICAgbmFtZT1cIkRlIEJ1cmdlclwiXHJcbiAgICAgICAgICBhZGRyZXNzPVwiTmVja2Vyc3BvZWwsIFN0YXRpb25zcGxlaW4gMjItMTcsIDU2MTEgQUQgRWluZGhvdmVuXCJcclxuICAgICAgICAgIGRpc3RhbmNlPVwiMS45XCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTdG9yZUJveFxyXG4gICAgICAgICAgbmFtZT1cIkFjdGlvblwiXHJcbiAgICAgICAgICBhZGRyZXNzPVwiTmVja2Vyc3BvZWwsIFN0YXRpb25zcGxlaW4gMjItMTcsIDU2MTEgQUQgRWluZGhvdmVuXCJcclxuICAgICAgICAgIGRpc3RhbmNlPVwiMS4yXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTdG9yZUJveFxyXG4gICAgICAgICAgbmFtZT1cIkNoaW5lc2UgZm9vZFwiXHJcbiAgICAgICAgICBhZGRyZXNzPVwiTmVja2Vyc3BvZWwsIFN0YXRpb25zcGxlaW4gMjItMTcsIDU2MTEgQUQgRWluZGhvdmVuXCJcclxuICAgICAgICAgIGRpc3RhbmNlPVwiMS45XCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTdG9yZUJveFxyXG4gICAgICAgICAgbmFtZT1cIkFsYmVydCBIZWlqblwiXHJcbiAgICAgICAgICBhZGRyZXNzPVwiTmVja2Vyc3BvZWwsIFN0YXRpb25zcGxlaW4gMjItMTcsIDU2MTEgQUQgRWluZGhvdmVuXCJcclxuICAgICAgICAgIGRpc3RhbmNlPVwiMS4yXCJcclxuICAgICAgICAvPlxyXG4gICAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdG9yZUxpc3Q7XHJcbiIsImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEdlb2NvZGUgZnJvbSBcInJlYWN0LWdlb2NvZGVcIjtcclxuaW1wb3J0IHsgbG9jYXRpb25MaXN0IH0gZnJvbSBcIi4uLy4uL2Fzc2V0cy9sb2NhdGlvbkxpc3RcIjtcclxuaW1wb3J0IHtcclxuICBHb29nbGVNYXAsXHJcbiAgTWFya2VyLFxyXG4gIHdpdGhTY3JpcHRqcyxcclxuICB3aXRoR29vZ2xlTWFwLFxyXG4gIEluZm9XaW5kb3csXHJcbn0gZnJvbSBcInJlYWN0LWdvb2dsZS1tYXBzXCI7XHJcbmltcG9ydCBtYXBTdHlsZXMgZnJvbSBcIi4vbWFwU3R5bGVzXCI7XHJcblxyXG5jb25zdCBNYXAgPSAocHJvcHMpID0+IHtcclxuICAvLyBTdGF0ZVxyXG4gIGNvbnN0IFt1c2VyUG9zaXRpb24sIHNldFVzZXJQb3NpdGlvbl0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtzdG9yZXMsIHNldFN0b3Jlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RvcmUsIHNldFNlbGVjdGVkU3RvcmVdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBHZXQgbG9jYXRpb24gb2YgdXNlclxyXG4gICAgaWYgKFwiZ2VvbG9jYXRpb25cIiBpbiBuYXZpZ2F0b3IpIHtcclxuICAgICAgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbihmdW5jdGlvbiAocG9zaXRpb24pIHtcclxuICAgICAgICBzZXRVc2VyUG9zaXRpb24oe1xyXG4gICAgICAgICAgbGF0OiBwb3NpdGlvbi5jb29yZHMubGF0aXR1ZGUsXHJcbiAgICAgICAgICBsbmc6IHBvc2l0aW9uLmNvb3Jkcy5sb25naXR1ZGUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coXCJHZW9sb2NhdGlvbiBOb3QgQXZhaWxhYmxlXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIC8vIFB1c2ggZGF0YSB0byBhIG5ldyBvYmplY3QgYXJyYXlcclxuICAgIC8vIGxldCBhbGxMb2NhdGlvbnMgPSBbXTtcclxuXHJcbiAgICAvLyAvLyBDb25uZWN0IHRvIEdvb2dsZSBrZXlcclxuICAgIC8vIEdlb2NvZGUuc2V0QXBpS2V5KHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0dPT0dMRV9LRVkpO1xyXG5cclxuICAgIC8vIGxldCBwcm9taXNlcyA9IFtdO1xyXG5cclxuICAgIC8vIGxvY2F0aW9uTGlzdC5tYXAoKHBsYWNlKSA9PiB7XHJcbiAgICAvLyAgIHByb21pc2VzLnB1c2goR2VvY29kZS5mcm9tQWRkcmVzcyhwbGFjZS5hZGRyZXNzKSk7XHJcblxyXG4gICAgLy8gfSk7XHJcblxyXG4gICAgLy8gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4oXHJcbiAgICAvLyAgICAgKG5ld0xvY2F0aW9ucykgPT4ge1xyXG4gICAgLy8gICAgICAgbmV3TG9jYXRpb25zLm1hcCgobG9jYXRpb24pID0+IHtcclxuICAgIC8vICAgICAgICAgLy8gICBjb25zb2xlLmxvZygnbG9jYXRpb24nLCBsb2NhdGlvbilcclxuICAgIC8vICAgICAgICAgY29uc3QgeyBsYXQsIGxuZyB9ID0gbG9jYXRpb24ucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbjtcclxuICAgIC8vICAgICAgICAgLy8gVXBkYXRlIGNvb3JkaW5hdGVzXHJcbiAgICAvLyAgICAgICAgIGxvY2F0aW9uID0geyAuLi5sb2NhdGlvbiwgbGF0OiBsYXQsIGxuZzogbG5nIH07XHJcblxyXG4gICAgLy8gICAgICAgICBhbGxMb2NhdGlvbnMucHVzaChsb2NhdGlvbik7XHJcbiAgICAvLyAgICAgICB9KTtcclxuICAgIC8vICAgICB9LFxyXG4gICAgLy8gICAgIChlcnJvcikgPT4ge1xyXG4gICAgLy8gICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICApO1xyXG5cclxuICAgIHNldFN0b3Jlcyhsb2NhdGlvbkxpc3QpO1xyXG5cclxuICAgIC8vIC8vIEdldCBsYXRpdHVkZSBhbmQgbG9uZ2l0dWRlIGZyb20gYWRkcmVzc1xyXG4gICAgLy8gYXdhaXQgR2VvY29kZS5mcm9tQWRkcmVzcyhwbGFjZS5hZGRyZXNzKS50aGVuKFxyXG4gICAgLy8gICAgIChyZXNwb25zZSkgPT4ge1xyXG4gICAgLy8gICAgICAgY29uc3QgeyBsYXQsIGxuZyB9ID0gcmVzcG9uc2UucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbjtcclxuICAgIC8vICAgICAgIC8vIFVwZGF0ZSBjb29yZGluYXRlc1xyXG4gICAgLy8gICAgICAgcGxhY2UgPSB7Li4ucGxhY2UsIGxhdDogbGF0LCBsbmc6IGxuZ31cclxuXHJcbiAgICAvLyAgICAgICBhbGxMb2NhdGlvbnMucHVzaChwbGFjZSk7XHJcbiAgICAvLyAgICAgfSxcclxuICAgIC8vICAgICAoZXJyb3IpID0+IHtcclxuICAgIC8vICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgKTtcclxuICAgIC8vICAgc2V0TG9jYXRpb25zKGFsbExvY2F0aW9ucyk7XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEdvb2dsZU1hcFxyXG4gICAgICBkZWZhdWx0Wm9vbT17MTN9XHJcbiAgICAgIGRlZmF1bHRDZW50ZXI9e3sgbGF0OiA1MS40NDA4MywgbG5nOiA1LjQ3Nzc4IH19XHJcbiAgICAgIGRlZmF1bHRPcHRpb25zPXt7IHN0eWxlczogbWFwU3R5bGVzIH19XHJcbiAgICA+XHJcbiAgICAgIHt1c2VyUG9zaXRpb24gJiYgKFxyXG4gICAgICAgIDxNYXJrZXJcclxuICAgICAgICAgIHBvc2l0aW9uPXt7IGxhdDogdXNlclBvc2l0aW9uLmxhdCwgbG5nOiB1c2VyUG9zaXRpb24ubG5nIH19XHJcbiAgICAgICAgICBpY29uPXt7XHJcbiAgICAgICAgICAgIHVybDogXCIvaW1hZ2VzL3VzZXJQb2ludGVyLnN2Z1wiLFxyXG4gICAgICAgICAgICBzY2FsZWRTaXplOiBuZXcgd2luZG93Lmdvb2dsZS5tYXBzLlNpemUoNDUsIDUwKSxcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHtzdG9yZXMgJiZcclxuICAgICAgICBzdG9yZXMubWFwKChzdG9yZSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICA8TWFya2VyXHJcbiAgICAgICAgICAgIGtleT17aWR4fVxyXG4gICAgICAgICAgICBwb3NpdGlvbj17eyBsYXQ6IHN0b3JlLmxhdCwgbG5nOiBzdG9yZS5sbmcgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTdG9yZShzdG9yZSl9XHJcbiAgICAgICAgICAgIGljb249e3tcclxuICAgICAgICAgICAgICB1cmw6IFwiL2ltYWdlcy9wb2ludGVyLnN2Z1wiLFxyXG4gICAgICAgICAgICAgIHNjYWxlZFNpemU6IG5ldyB3aW5kb3cuZ29vZ2xlLm1hcHMuU2l6ZSg0NSwgNTApLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApKX1cclxuICAgICAge3NlbGVjdGVkU3RvcmUgJiYgKFxyXG4gICAgICAgIDxJbmZvV2luZG93XHJcbiAgICAgICAgICBwb3NpdGlvbj17eyBsYXQ6IHNlbGVjdGVkU3RvcmUubGF0LCBsbmc6IHNlbGVjdGVkU3RvcmUubG5nIH19XHJcbiAgICAgICAgICBvbkNsb3NlQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU3RvcmUobnVsbCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGg0PiB7c2VsZWN0ZWRTdG9yZS5uYW1lfTwvaDQ+XHJcbiAgICAgICAgICAgIDxwPntzZWxlY3RlZFN0b3JlLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9JbmZvV2luZG93PlxyXG4gICAgICApfVxyXG4gICAgPC9Hb29nbGVNYXA+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHdpdGhTY3JpcHRqcyh3aXRoR29vZ2xlTWFwKE1hcCkpO1xyXG4iLCJleHBvcnQgZGVmYXVsdCBbXHJcbiAgICB7XHJcbiAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcImxhbmRzY2FwZS5tYW5fbWFkZVwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjZjdmMWRmXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcImxhbmRzY2FwZS5uYXR1cmFsXCIsXHJcbiAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImdlb21ldHJ5XCIsXHJcbiAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBcIiNkMGUzYjRcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwibGFuZHNjYXBlLm5hdHVyYWwudGVycmFpblwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiBcIm9mZlwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJwb2lcIixcclxuICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzXCIsXHJcbiAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwib2ZmXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInBvaS5idXNpbmVzc1wiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJhbGxcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJvZmZcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicG9pLm1lZGljYWxcIixcclxuICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiZ2VvbWV0cnlcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2ZiZDNkYVwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJwb2kucGFya1wiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjYmRlNmFiXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInJvYWRcIixcclxuICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiYWxsXCIsXHJcbiAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwib25cIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicm9hZFwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeS5zdHJva2VcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJvZmZcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicm9hZFwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJsYWJlbHNcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJvblwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmhpZ2h3YXlcIixcclxuICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiZ2VvbWV0cnkuZmlsbFwiLFxyXG4gICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjZmZlMTVmXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInJvYWQuaGlnaHdheVwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeS5zdHJva2VcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2VmZDE1MVwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmFydGVyaWFsXCIsXHJcbiAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImdlb21ldHJ5LmZpbGxcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2ZmZmZmZlwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmxvY2FsXCIsXHJcbiAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImdlb21ldHJ5LmZpbGxcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiYmxhY2tcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwidHJhbnNpdFwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiBcIm9mZlwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJ0cmFuc2l0LnN0YXRpb24uYWlycG9ydFwiLFxyXG4gICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeS5maWxsXCIsXHJcbiAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBcIiNjZmIyZGJcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgXVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwid2F0ZXJcIixcclxuICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiZ2VvbWV0cnlcIixcclxuICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2EyZGFmMlwiXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9XHJcbl0iLCJpbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyBQdXJlQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgQ29udHJvbFBhbmVsIGZyb20gXCIuLi9jb21wb25lbnRzL0NvbnRyb2xQYW5lbC9Db250cm9sUGFuZWxcIjtcbmltcG9ydCBNYXAgZnJvbSBcIi4uL2NvbXBvbmVudHMvTWFwL01hcFwiO1xuaW1wb3J0IGNsYXNzZXMgZnJvbSBcIi4uL3N0eWxlcy9Ib21lLm1vZHVsZS5zY3NzXCI7XG5cbmNsYXNzIEhvbWUgZXh0ZW5kcyBQdXJlQ29tcG9uZW50IHtcbiAgc3RhdGUgPSB7XG4gICAgc3RvcmVUeXBlOiBudWxsLFxuICAgIHNvcnRCeTogbnVsbCxcbiAgICByYW5nZTogbnVsbCxcbiAgICBsb2NhdGlvbjogbnVsbCxcbiAgfTtcblxuICBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSAoZSkgPT4ge1xuICAgIC8vIFVwZGF0ZSBzdGF0ZSBmaWx0ZXIgdmFsdWVcbiAgICB0aGlzLnNldFN0YXRlKHsgLi4udGhpcy5zdGF0ZSxcbiAgICAgIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUgfSk7XG4gICAgfTtcblxuXG4gIHJlbmRlcigpIHtcbiAgICBsZXQgbWFpbkNvbnRhaW5lckNsYXNzZXMgPSBbY2xhc3Nlcy5tYWluX2NvbnRhaW5lciwgXCJyb3dcIl07XG5cbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvXCI+XG4gICAgICAgIDxIZWFkPlxuICAgICAgICAgIDx0aXRsZT5HcmFiIGFuZCBHbzwvdGl0bGU+XG4gICAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgICA8L0hlYWQ+XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT17bWFpbkNvbnRhaW5lckNsYXNzZXMuam9pbihcIiBcIil9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1sZy03IHB4LTBcIiBzdHlsZT17eyBoZWlnaHQ6IFwiMTAwdmhcIiB9fT5cbiAgICAgICAgICAgIDxNYXBcbiAgICAgICAgICAgICAgZ29vZ2xlTWFwVVJMPXtgaHR0cHM6Ly9tYXBzLmdvb2dsZWFwaXMuY29tL21hcHMvYXBpL2pzP3Y9My5leHAmbGlicmFyaWVzPWdlb21ldHJ5LGRyYXdpbmcscGxhY2VzJmtleT0ke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0dPT0dMRV9LRVl9YH1cbiAgICAgICAgICAgICAgbG9hZGluZ0VsZW1lbnQ9ezxkaXYgc3R5bGU9e3sgaGVpZ2h0OiBgMTAwJWAgfX0gLz59XG4gICAgICAgICAgICAgIGNvbnRhaW5lckVsZW1lbnQ9ezxkaXYgc3R5bGU9e3sgaGVpZ2h0OiBgMTAwJWAgfX0gLz59XG4gICAgICAgICAgICAgIG1hcEVsZW1lbnQ9ezxkaXYgc3R5bGU9e3sgaGVpZ2h0OiBgMTAwJWAgfX0gLz59XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTEyIGNvbC1sZy01IHB4LTBcIj5cbiAgICAgICAgICAgIDxDb250cm9sUGFuZWwgaGFuZGxlRmlsdGVyQ2hhbmdlPXsoZSkgPT4gdGhpcy5oYW5kbGVGaWx0ZXJDaGFuZ2UoZSl9Lz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBIb21lO1xuIiwiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwibWFpbl9jb250YWluZXJcIjogXCJIb21lX21haW5fY29udGFpbmVyX19PLVpoYVwiLFxuXHRcImNvbnRyb2xfcGFuZWxcIjogXCJIb21lX2NvbnRyb2xfcGFuZWxfXzFFNkpzXCIsXG5cdFwid2hpdGVfY29udGFpbmVyXCI6IFwiSG9tZV93aGl0ZV9jb250YWluZXJfXzJuSmYyXCJcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9Gb3JtQ29udHJvbFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9JbnB1dExhYmVsXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1NlbGVjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWdlb2NvZGVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtZ29vZ2xlLW1hcHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=