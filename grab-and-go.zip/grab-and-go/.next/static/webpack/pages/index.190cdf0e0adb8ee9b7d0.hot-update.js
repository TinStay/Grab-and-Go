webpackHotUpdate_N_E("pages/index",{

/***/ "./components/Map/Map.js":
/*!*******************************!*\
  !*** ./components/Map/Map.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_geocode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-geocode */ "./node_modules/react-geocode/lib/index.js");
/* harmony import */ var react_geocode__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_geocode__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_locationList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/locationList */ "./assets/locationList.js");
/* harmony import */ var react_google_maps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-google-maps */ "./node_modules/react-google-maps/lib/index.js");
/* harmony import */ var react_google_maps__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_google_maps__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mapStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mapStyles */ "./components/Map/mapStyles.js");


var _jsxFileName = "D:\\Code\\Grab and Go\\grab-and-go\\components\\Map\\Map.js",
    _this = undefined,
    _s = $RefreshSig$();







var Map = function Map(props) {
  _s();

  // State
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(),
      userPosition = _useState[0],
      setUserPosition = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]),
      stores = _useState2[0],
      setStores = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null),
      selectedStore = _useState3[0],
      setSelectedStore = _useState3[1];

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    // Get location of user
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(function (position) {
        setUserPosition({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      });
    } else {
      console.log("Geolocation Not Available");
    } // // Push data to a new object array
    // let allLocations = [];
    // // Connect to Google key
    // Geocode.setApiKey(process.env.NEXT_PUBLIC_GOOGLE_KEY);
    // let promises = [];
    // locationList.map((place) => {
    //   promises.push(Geocode.fromAddress(place.address));
    // });
    // Promise.all(promises).then(
    //     (newLocations) => {
    //       newLocations.map((location) => {
    //         //   console.log('location', location)
    //         const { lat, lng } = location.results[0].geometry.location;
    //         // Update coordinates
    //         location = { ...location, lat: lat, lng: lng };
    //         allLocations.push(location);
    //       });
    //     },
    //     (error) => {
    //       console.error(error);
    //     }
    //   );


    setStores(_assets_locationList__WEBPACK_IMPORTED_MODULE_3__["locationList"]); // // Get latitude and longitude from address
    // await Geocode.fromAddress(place.address).then(
    //     (response) => {
    //       const { lat, lng } = response.results[0].geometry.location;
    //       // Update coordinates
    //       place = {...place, lat: lat, lng: lng}
    //       allLocations.push(place);
    //     },
    //     (error) => {
    //       console.error(error);
    //     }
    //   );
    //   setLocations(allLocations);
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["GoogleMap"], {
    defaultZoom: 13,
    defaultCenter: {
      lat: 51.44083,
      lng: 5.47778
    },
    defaultOptions: {
      styles: _mapStyles__WEBPACK_IMPORTED_MODULE_5__["default"]
    },
    children: [userPosition && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["Marker"], {
      position: {
        lat: userPosition.lat,
        lng: userPosition.lng
      },
      icon: {
        url: "/images/userPointer.svg",
        scaledSize: new window.google.maps.Size(45, 50)
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 9
    }, _this), stores && stores.map(function (store, idx) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["Marker"], {
        position: {
          lat: store.lat,
          lng: store.lng
        },
        onClick: function onClick() {
          return setSelectedStore(store);
        },
        icon: {
          url: "/images/pointer.svg",
          scaledSize: new window.google.maps.Size(45, 50)
        }
      }, idx, false, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 11
      }, _this);
    }), selectedStore && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["InfoWindow"], {
      position: {
        lat: selectedStore.lat,
        lng: selectedStore.lng
      },
      onCloseClick: function onCloseClick() {
        return setSelectedStore(null);
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
          children: [" ", selectedStore.name]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 13
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: selectedStore.address
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 114,
          columnNumber: 13
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 11
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 108,
      columnNumber: 9
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 80,
    columnNumber: 5
  }, _this);
};

_s(Map, "MVlE4uLW8+TL2k4O1rDNZctF9ks=");

_c = Map;
/* harmony default export */ __webpack_exports__["default"] = (_c3 = Object(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["withScriptjs"])(_c2 = Object(react_google_maps__WEBPACK_IMPORTED_MODULE_4__["withGoogleMap"])(Map)));

var _c, _c2, _c3;

$RefreshReg$(_c, "Map");
$RefreshReg$(_c2, "%default%$withScriptjs");
$RefreshReg$(_c3, "%default%");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9NYXAvTWFwLmpzIl0sIm5hbWVzIjpbIk1hcCIsInByb3BzIiwidXNlU3RhdGUiLCJ1c2VyUG9zaXRpb24iLCJzZXRVc2VyUG9zaXRpb24iLCJzdG9yZXMiLCJzZXRTdG9yZXMiLCJzZWxlY3RlZFN0b3JlIiwic2V0U2VsZWN0ZWRTdG9yZSIsInVzZUVmZmVjdCIsIm5hdmlnYXRvciIsImdlb2xvY2F0aW9uIiwiZ2V0Q3VycmVudFBvc2l0aW9uIiwicG9zaXRpb24iLCJsYXQiLCJjb29yZHMiLCJsYXRpdHVkZSIsImxuZyIsImxvbmdpdHVkZSIsImNvbnNvbGUiLCJsb2ciLCJsb2NhdGlvbkxpc3QiLCJzdHlsZXMiLCJtYXBTdHlsZXMiLCJ1cmwiLCJzY2FsZWRTaXplIiwid2luZG93IiwiZ29vZ2xlIiwibWFwcyIsIlNpemUiLCJtYXAiLCJzdG9yZSIsImlkeCIsIm5hbWUiLCJhZGRyZXNzIiwid2l0aFNjcmlwdGpzIiwid2l0aEdvb2dsZU1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFPQTs7QUFFQSxJQUFNQSxHQUFHLEdBQUcsU0FBTkEsR0FBTSxDQUFDQyxLQUFELEVBQVc7QUFBQTs7QUFDckI7QUFEcUIsa0JBRW1CQyxzREFBUSxFQUYzQjtBQUFBLE1BRWRDLFlBRmM7QUFBQSxNQUVBQyxlQUZBOztBQUFBLG1CQUdPRixzREFBUSxDQUFDLEVBQUQsQ0FIZjtBQUFBLE1BR2RHLE1BSGM7QUFBQSxNQUdOQyxTQUhNOztBQUFBLG1CQUlxQkosc0RBQVEsQ0FBQyxJQUFELENBSjdCO0FBQUEsTUFJZEssYUFKYztBQUFBLE1BSUNDLGdCQUpEOztBQU1yQkMseURBQVMsQ0FBQyxZQUFNO0FBQ2Q7QUFDQSxRQUFJLGlCQUFpQkMsU0FBckIsRUFBZ0M7QUFDOUJBLGVBQVMsQ0FBQ0MsV0FBVixDQUFzQkMsa0JBQXRCLENBQXlDLFVBQVVDLFFBQVYsRUFBb0I7QUFDM0RULHVCQUFlLENBQUM7QUFDZFUsYUFBRyxFQUFFRCxRQUFRLENBQUNFLE1BQVQsQ0FBZ0JDLFFBRFA7QUFFZEMsYUFBRyxFQUFFSixRQUFRLENBQUNFLE1BQVQsQ0FBZ0JHO0FBRlAsU0FBRCxDQUFmO0FBSUQsT0FMRDtBQU1ELEtBUEQsTUFPTztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSwyQkFBWjtBQUNELEtBWGEsQ0FhZDtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUFkLGFBQVMsQ0FBQ2UsaUVBQUQsQ0FBVCxDQTFDYyxDQTRDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNELEdBMURRLEVBMEROLEVBMURNLENBQVQ7QUE0REEsc0JBQ0UscUVBQUMsMkRBQUQ7QUFDRSxlQUFXLEVBQUUsRUFEZjtBQUVFLGlCQUFhLEVBQUU7QUFBRVAsU0FBRyxFQUFFLFFBQVA7QUFBaUJHLFNBQUcsRUFBRTtBQUF0QixLQUZqQjtBQUdFLGtCQUFjLEVBQUU7QUFBRUssWUFBTSxFQUFFQyxrREFBU0E7QUFBbkIsS0FIbEI7QUFBQSxlQUtHcEIsWUFBWSxpQkFDWCxxRUFBQyx3REFBRDtBQUNFLGNBQVEsRUFBRTtBQUFFVyxXQUFHLEVBQUVYLFlBQVksQ0FBQ1csR0FBcEI7QUFBeUJHLFdBQUcsRUFBRWQsWUFBWSxDQUFDYztBQUEzQyxPQURaO0FBRUUsVUFBSSxFQUFFO0FBQ0pPLFdBQUcsRUFBRSx5QkFERDtBQUVKQyxrQkFBVSxFQUFFLElBQUlDLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjQyxJQUFkLENBQW1CQyxJQUF2QixDQUE0QixFQUE1QixFQUFnQyxFQUFoQztBQUZSO0FBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU5KLEVBZUd4QixNQUFNLElBQ0xBLE1BQU0sQ0FBQ3lCLEdBQVAsQ0FBVyxVQUFDQyxLQUFELEVBQVFDLEdBQVI7QUFBQSwwQkFDVCxxRUFBQyx3REFBRDtBQUVFLGdCQUFRLEVBQUU7QUFBRWxCLGFBQUcsRUFBRWlCLEtBQUssQ0FBQ2pCLEdBQWI7QUFBa0JHLGFBQUcsRUFBRWMsS0FBSyxDQUFDZDtBQUE3QixTQUZaO0FBR0UsZUFBTyxFQUFFO0FBQUEsaUJBQU1ULGdCQUFnQixDQUFDdUIsS0FBRCxDQUF0QjtBQUFBLFNBSFg7QUFJRSxZQUFJLEVBQUU7QUFDSlAsYUFBRyxFQUFFLHFCQUREO0FBRUpDLG9CQUFVLEVBQUUsSUFBSUMsTUFBTSxDQUFDQyxNQUFQLENBQWNDLElBQWQsQ0FBbUJDLElBQXZCLENBQTRCLEVBQTVCLEVBQWdDLEVBQWhDO0FBRlI7QUFKUixTQUNPRyxHQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEUztBQUFBLEtBQVgsQ0FoQkosRUEyQkd6QixhQUFhLGlCQUNaLHFFQUFDLDREQUFEO0FBQ0UsY0FBUSxFQUFFO0FBQUVPLFdBQUcsRUFBRVAsYUFBYSxDQUFDTyxHQUFyQjtBQUEwQkcsV0FBRyxFQUFFVixhQUFhLENBQUNVO0FBQTdDLE9BRFo7QUFFRSxrQkFBWSxFQUFFO0FBQUEsZUFBTVQsZ0JBQWdCLENBQUMsSUFBRCxDQUF0QjtBQUFBLE9BRmhCO0FBQUEsNkJBSUU7QUFBQSxnQ0FDRTtBQUFBLDBCQUFNRCxhQUFhLENBQUMwQixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUFBLG9CQUFJMUIsYUFBYSxDQUFDMkI7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBeUNELENBM0dEOztHQUFNbEMsRzs7S0FBQUEsRztBQTZHUyxxRUFBQW1DLHNFQUFZLE9BQUNDLHVFQUFhLENBQUNwQyxHQUFELENBQWQsQ0FBM0IiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMTkwY2RmMGUwYWRiOGVlOWI3ZDAuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEdlb2NvZGUgZnJvbSBcInJlYWN0LWdlb2NvZGVcIjtcclxuaW1wb3J0IHsgbG9jYXRpb25MaXN0IH0gZnJvbSBcIi4uLy4uL2Fzc2V0cy9sb2NhdGlvbkxpc3RcIjtcclxuaW1wb3J0IHtcclxuICBHb29nbGVNYXAsXHJcbiAgTWFya2VyLFxyXG4gIHdpdGhTY3JpcHRqcyxcclxuICB3aXRoR29vZ2xlTWFwLFxyXG4gIEluZm9XaW5kb3csXHJcbn0gZnJvbSBcInJlYWN0LWdvb2dsZS1tYXBzXCI7XHJcbmltcG9ydCBtYXBTdHlsZXMgZnJvbSBcIi4vbWFwU3R5bGVzXCI7XHJcblxyXG5jb25zdCBNYXAgPSAocHJvcHMpID0+IHtcclxuICAvLyBTdGF0ZVxyXG4gIGNvbnN0IFt1c2VyUG9zaXRpb24sIHNldFVzZXJQb3NpdGlvbl0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtzdG9yZXMsIHNldFN0b3Jlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RvcmUsIHNldFNlbGVjdGVkU3RvcmVdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBHZXQgbG9jYXRpb24gb2YgdXNlclxyXG4gICAgaWYgKFwiZ2VvbG9jYXRpb25cIiBpbiBuYXZpZ2F0b3IpIHtcclxuICAgICAgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbihmdW5jdGlvbiAocG9zaXRpb24pIHtcclxuICAgICAgICBzZXRVc2VyUG9zaXRpb24oe1xyXG4gICAgICAgICAgbGF0OiBwb3NpdGlvbi5jb29yZHMubGF0aXR1ZGUsXHJcbiAgICAgICAgICBsbmc6IHBvc2l0aW9uLmNvb3Jkcy5sb25naXR1ZGUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coXCJHZW9sb2NhdGlvbiBOb3QgQXZhaWxhYmxlXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIC8vIFB1c2ggZGF0YSB0byBhIG5ldyBvYmplY3QgYXJyYXlcclxuICAgIC8vIGxldCBhbGxMb2NhdGlvbnMgPSBbXTtcclxuXHJcbiAgICAvLyAvLyBDb25uZWN0IHRvIEdvb2dsZSBrZXlcclxuICAgIC8vIEdlb2NvZGUuc2V0QXBpS2V5KHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0dPT0dMRV9LRVkpO1xyXG5cclxuICAgIC8vIGxldCBwcm9taXNlcyA9IFtdO1xyXG5cclxuICAgIC8vIGxvY2F0aW9uTGlzdC5tYXAoKHBsYWNlKSA9PiB7XHJcbiAgICAvLyAgIHByb21pc2VzLnB1c2goR2VvY29kZS5mcm9tQWRkcmVzcyhwbGFjZS5hZGRyZXNzKSk7XHJcblxyXG4gICAgLy8gfSk7XHJcblxyXG4gICAgLy8gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4oXHJcbiAgICAvLyAgICAgKG5ld0xvY2F0aW9ucykgPT4ge1xyXG4gICAgLy8gICAgICAgbmV3TG9jYXRpb25zLm1hcCgobG9jYXRpb24pID0+IHtcclxuICAgIC8vICAgICAgICAgLy8gICBjb25zb2xlLmxvZygnbG9jYXRpb24nLCBsb2NhdGlvbilcclxuICAgIC8vICAgICAgICAgY29uc3QgeyBsYXQsIGxuZyB9ID0gbG9jYXRpb24ucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbjtcclxuICAgIC8vICAgICAgICAgLy8gVXBkYXRlIGNvb3JkaW5hdGVzXHJcbiAgICAvLyAgICAgICAgIGxvY2F0aW9uID0geyAuLi5sb2NhdGlvbiwgbGF0OiBsYXQsIGxuZzogbG5nIH07XHJcblxyXG4gICAgLy8gICAgICAgICBhbGxMb2NhdGlvbnMucHVzaChsb2NhdGlvbik7XHJcbiAgICAvLyAgICAgICB9KTtcclxuICAgIC8vICAgICB9LFxyXG4gICAgLy8gICAgIChlcnJvcikgPT4ge1xyXG4gICAgLy8gICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICApO1xyXG5cclxuICAgIHNldFN0b3Jlcyhsb2NhdGlvbkxpc3QpO1xyXG5cclxuICAgIC8vIC8vIEdldCBsYXRpdHVkZSBhbmQgbG9uZ2l0dWRlIGZyb20gYWRkcmVzc1xyXG4gICAgLy8gYXdhaXQgR2VvY29kZS5mcm9tQWRkcmVzcyhwbGFjZS5hZGRyZXNzKS50aGVuKFxyXG4gICAgLy8gICAgIChyZXNwb25zZSkgPT4ge1xyXG4gICAgLy8gICAgICAgY29uc3QgeyBsYXQsIGxuZyB9ID0gcmVzcG9uc2UucmVzdWx0c1swXS5nZW9tZXRyeS5sb2NhdGlvbjtcclxuICAgIC8vICAgICAgIC8vIFVwZGF0ZSBjb29yZGluYXRlc1xyXG4gICAgLy8gICAgICAgcGxhY2UgPSB7Li4ucGxhY2UsIGxhdDogbGF0LCBsbmc6IGxuZ31cclxuXHJcbiAgICAvLyAgICAgICBhbGxMb2NhdGlvbnMucHVzaChwbGFjZSk7XHJcbiAgICAvLyAgICAgfSxcclxuICAgIC8vICAgICAoZXJyb3IpID0+IHtcclxuICAgIC8vICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgKTtcclxuICAgIC8vICAgc2V0TG9jYXRpb25zKGFsbExvY2F0aW9ucyk7XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEdvb2dsZU1hcFxyXG4gICAgICBkZWZhdWx0Wm9vbT17MTN9XHJcbiAgICAgIGRlZmF1bHRDZW50ZXI9e3sgbGF0OiA1MS40NDA4MywgbG5nOiA1LjQ3Nzc4IH19XHJcbiAgICAgIGRlZmF1bHRPcHRpb25zPXt7IHN0eWxlczogbWFwU3R5bGVzIH19XHJcbiAgICA+XHJcbiAgICAgIHt1c2VyUG9zaXRpb24gJiYgKFxyXG4gICAgICAgIDxNYXJrZXJcclxuICAgICAgICAgIHBvc2l0aW9uPXt7IGxhdDogdXNlclBvc2l0aW9uLmxhdCwgbG5nOiB1c2VyUG9zaXRpb24ubG5nIH19XHJcbiAgICAgICAgICBpY29uPXt7XHJcbiAgICAgICAgICAgIHVybDogXCIvaW1hZ2VzL3VzZXJQb2ludGVyLnN2Z1wiLFxyXG4gICAgICAgICAgICBzY2FsZWRTaXplOiBuZXcgd2luZG93Lmdvb2dsZS5tYXBzLlNpemUoNDUsIDUwKSxcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHtzdG9yZXMgJiZcclxuICAgICAgICBzdG9yZXMubWFwKChzdG9yZSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICA8TWFya2VyXHJcbiAgICAgICAgICAgIGtleT17aWR4fVxyXG4gICAgICAgICAgICBwb3NpdGlvbj17eyBsYXQ6IHN0b3JlLmxhdCwgbG5nOiBzdG9yZS5sbmcgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTdG9yZShzdG9yZSl9XHJcbiAgICAgICAgICAgIGljb249e3tcclxuICAgICAgICAgICAgICB1cmw6IFwiL2ltYWdlcy9wb2ludGVyLnN2Z1wiLFxyXG4gICAgICAgICAgICAgIHNjYWxlZFNpemU6IG5ldyB3aW5kb3cuZ29vZ2xlLm1hcHMuU2l6ZSg0NSwgNTApLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApKX1cclxuICAgICAge3NlbGVjdGVkU3RvcmUgJiYgKFxyXG4gICAgICAgIDxJbmZvV2luZG93XHJcbiAgICAgICAgICBwb3NpdGlvbj17eyBsYXQ6IHNlbGVjdGVkU3RvcmUubGF0LCBsbmc6IHNlbGVjdGVkU3RvcmUubG5nIH19XHJcbiAgICAgICAgICBvbkNsb3NlQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU3RvcmUobnVsbCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGg0PiB7c2VsZWN0ZWRTdG9yZS5uYW1lfTwvaDQ+XHJcbiAgICAgICAgICAgIDxwPntzZWxlY3RlZFN0b3JlLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9JbmZvV2luZG93PlxyXG4gICAgICApfVxyXG4gICAgPC9Hb29nbGVNYXA+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHdpdGhTY3JpcHRqcyh3aXRoR29vZ2xlTWFwKE1hcCkpO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9